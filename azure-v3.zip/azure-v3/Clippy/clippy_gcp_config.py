#  for clippy
admin_passwd='gsh$Ilm&i'
azure_zones=["gcp.com"]                                                                     #different zones
azure_comps=[
        ["safeway.ilp.receiptiq.com","safeway.ilpuat.receiptiq.com"]
        ]                                                                                                                     #components of each zone in order of zone
viewonlygcpcomps=[]                                                                                                              #Components in view only mode
email_to = ["ts@quotient.com"] #to_sent email list

