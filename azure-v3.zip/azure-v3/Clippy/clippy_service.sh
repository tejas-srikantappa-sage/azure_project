#!/bin/bash

### BEGIN INIT INFO
# Provides:                 clippy
# Required-Start:           $python
# Required-Stop:            $python
# Short-Description:        Start and stop clippy service.
# Description:              -
# Date-Creation:            -
# Date-Last-Modification:   -
# Author:                   - Picklu Paul <ppaul@quotient.com>
### END INIT INFO

# Variables
PGREP=/usr/bin/pgrep
python=/opt/Clippy/myenv/bin/python
ZERO=0
RIQ_CONF_COMPILED=/opt/Clippy/riqconfig.pyc
# Start the clippy
start() {
    echo "Starting clippy..."
    #Verify if the service is running
    $PGREP -f /opt/Clippy/clippy.py
    VERIFIER=$?
    if [ $ZERO = $VERIFIER ]
    then
        echo "The service is already running"
    else
        if [ -f $RIQ_CONF_COMPILED ] ; then
             rm $RIQ_CONF_COMPILED #remove old riqconfig.py
        fi
        #Run the python script clippy service
        nohup $python /opt/Clippy/clippy.py > /dev/null 2>&1 &
        #sleep time before the service verification
        sleep 5
        #Verify if the service is running
        $PGREP -f /opt/Clippy/clippy.py > /dev/null
        VERIFIER=$?
        if [ $ZERO = $VERIFIER ]
        then
            renice -n -19 -p $($PGREP -f /opt/Clippy/clippy.py)
            echo "Service was successfully started"
        else
            echo "Failed to start service"
        fi
    fi
    echo
}

# Stop the clippy
stop() {
    echo "Stopping clippy..."
    #Verify if the service is running
    $PGREP -f /opt/Clippy/clippy.py > /dev/null
    VERIFIER=$?
    if [ $ZERO = $VERIFIER ]
    then
        #Kill the pid of python with the service name
        kill -9 $($PGREP -f /opt/Clippy/clippy.py)
        #Sleep time before the service verification
        sleep 10
        #Verify if the service is running
        $PGREP -f /opt/Clippy/clippy.py > /dev/null
        VERIFIER=$?
        if [ $ZERO = $VERIFIER ]
        then
            echo "Failed to stop service"
        else
            echo "Service was successfully stopped"
        fi
    else
        echo "The service is already stopped"
    fi
    echo
}

# Verify the status of clippy
status() {
    echo "Checking status of clippy..."
    #Verify if the service is running
    $PGREP -f /opt/Clippy/clippy.py > /dev/null
    VERIFIER=$?
    if [ $ZERO = $VERIFIER ]
    then
        echo "Service is running"
    else
        echo "Service is stopped"
    fi
    echo
}

# Main logic
case "$1" in
    start)
        start
        ;;
    stop)
        stop
        ;;
    status)
        status
        ;;
    restart|reload)
        stop
        sleep 5
        start
        ;;
  *)
    echo $"Usage: $0 {start|stop|status|restart|reload}"
    exit 1
esac
exit 0
