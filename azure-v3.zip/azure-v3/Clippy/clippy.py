'''
This script is used to make changes in Akamai Luna through api calls.
Below are the more details mentioned.
'''
from flask import Flask,flash,render_template,request,redirect,url_for,session
import copy
import datetime
import json
import json_delta
import os
from urlparse import urljoin
from akamai.edgegrid import EdgeGridAuth
import requests,re,copy
from flask_mail import Message,Mail
import clippyconfig
import clippy_azure_config
import ldap
import riqconfig
import collections
import re
import py_compile
from collections import OrderedDict

__author__ = "Picklu Paul"
__copyright__ = "Copyright 2018, Quotient"
__version__ = "2.0"
__maintainer__ = "Picklu Paul"
__email__ = "ppaul@quotient.com"
__status__ = "Production"


######################################################### Data ############################################

#ldap
ldap_bind_name = "LDAPBind2"
ldap_bind_pass = "LD@PB1nd2"
ldap_uri = 'ldap://ldap.corp.coupons.com'

#akamai
client_secret = "gaO23V9AWM1t5rxXzK1R+SBKJcO/uIIl9nXjv3eCy0o="
base_url = "https://akab-tnblk4ps4n6l4sfx-3hyqrkalghctrz7h.luna.akamaiapis.net"
access_token = "akab-ltw6wygzpxhm57y5-7nvlmvdyhdyeoit7"
client_token = "akab-qaz7vr2pu5tb53qr-tta5zu4muocfnbc2"
eg_auth_obj = EdgeGridAuth(client_token=client_token, client_secret=client_secret, access_token=access_token, max_body=400000)

#flask
app = Flask(__name__)
app.config.from_object(__name__)
app.secret_key = 'hja872khw9802hdh'


#coupons data
zones=clippyconfig.zones
comps=clippyconfig.comps
viewonlycomps=clippyconfig.viewonlycomps
comp_dict={}
for x in zones:
	comp_dict[x]={}
#gcp data
gcp_comps = {'sfwy-ILP':"safeway.ilp.receiptiq.com",'sfwy-UAT':"safeway.ilpuat.receiptiq.com"}
maps_dict = { 'Pilot2': "34.96.118.13", 'Pilot3' : "34.96.95.150", 'UAT1-gke01' : "35.244.203.78",'UAT2-gke02':"35.227.245.113" ,'cluster01' : "34.96.92.166", 'cluster02' : "35.201.98.229",
                 'west_cluster02' : "107.178.242.73"}
admin_passwd='gsh$Ilm&i'
#gcp_zones=clippy_gcp_config.gcp_zones
#gcp_comps=clippy_gcp_config.gcp_comps
#viewonlygcpcomps=clippy_gcp_config.viewonlygcpcomps
gcp_dict={}
gcp_comp={}
g_list=[]
#maps_dict={}
#for x in gcp_zones:
    #gcp_dict[x]={}
#renew data

#azurenew_comps = {'codes-east': "origin-codes-east.coupons.com", 'codes-west': "origin-codes-west.coupons.com", 'codesapiweb_E': "origin-codesapiweb-east.coupons.com", 'codesapiweb-W': "origin-codesapiweb-west.coupons.com" }
#azurenew_maps_dict = dict(F_east="9e64b0e9-4553-41ca-ada4-4e064be73885.cloudapp.net.", F_west="ea5d7601-6ca4-4b09-b72c-68f651a0b8d3.cloudapp.net.", B_east="appgatewayapi.eastus.cloudapp.azure.com.",
#B_west="appgatewayapi.westus.cloudapp.azure.com.")

#azure_list = []
#Azure data
admin_passwd=clippy_azure_config.admin_passwd
azure_zones=clippy_azure_config.azure_zones
azure_comps=clippy_azure_config.azure_comps
viewonlyazurecomps=clippy_azure_config.viewonlyazurecomps
azure_dict={}
azure_comp={}
for x in azure_zones:
        azure_dict[x]={}

#Azure_regex list

clippy_azure_regex=OrderedDict()
clippy_azure_regex['CMS-FE']="origin-cms-([a-z]+).coupons.com"
clippy_azure_regex['CMS-BE']="origin-codesapi-([a-z]+).coupons.com"
clippy_azure_regex['renew-FE']="origin-codes-([a-z]+).coupons.com"
clippy_azure_regex['renew-BE']="origin-codesapiweb-([a-z]+).coupons.com"
clippy_azure_regex['CodesPlugin-FE']="codesplugin-([a-z]+).coupons.com"
clippy_azure_regex['CodesPlugin-BE']="codespluginweb-([a-z]+).coupons.com"
clippy_azure_regex['Clippytest']="clippytest.([A-Za-z0-9]+).coupons.com"

#clippy_azure_regex= {
#    'CMS-FE': "origin-cms-([a-z]+).coupons.com",
#    'CMS-BE': "origin-codesapi-([a-z]+).coupons.com",
#    'renew-FE': "origin-codes-([a-z]+).coupons.com",
#    'renew-BE': "origin-codesapiweb-([a-z]+).coupons.com",
#    'CodesPlugin-FE': "codesplugin-([a-z]+).coupons.com",
#    'CodesPlugin-BE': "codespluginweb-([a-z]+).coupons.com",
#    'Clippytest':"clippytest.([A-Za-z0-9]+).coupons.com"
#}

#used for url making
clippy_azure_url=OrderedDict()
clippy_azure_url['CMS-FE']= "codes.geo"
clippy_azure_url['CMS-BE']= "codesapi.geo"
clippy_azure_url['renew-FE']= "codes.origin.geo"
clippy_azure_url['renew-BE']= "Codesapiweb.geo"
clippy_azure_url['CodesPlugin-FE']= "codesplugin.origin.geo"
clippy_azure_url['CodesPlugin-BE']= "codespluginweb.origin.geo"
clippy_azure_url['Clippytest']= "coupons.clippytest.geo"

#riq data
riq_zones=riqconfig.riq_zones
patner_list=riqconfig.patner_list
riq_all_comp=riqconfig.riq_all_comp
pattern_uxm=r'([a-zA-Z0-9]*)([.-]?uxm)(\..*\.com.)'
pattern_glsb=r'^(apir|apis)([0-9]*)(.?\.[a-zA-Z0-9-]*gslb.*?)(\.[a-zA-Z0-9]*\.com.)'
riq_dict={}
for x in riq_zones:
  riq_dict[x]={}

#logging
if not app.debug:
 import logging
 logging.basicConfig(filename='/var/log/clippy.log',format='%(asctime)s-[%(levelname)s]: %(message)s', level=logging.WARNING)

#mailing
email_from = 'clippy@couponsinc.com'
email_to = clippyconfig.email_to
app.config['MAIL_SERVER']= '127.0.0.1'
mail = Mail(app)
def sendemail(email_diff,zone,comments):
        msg = Message(subject="[Clippy]: Traffic Shift in "+zone,
                      sender=email_from,
                      recipients=email_to,
                      html=render_template('email.html', email_diff=email_diff, comments=comments,zone=zone,user=session['username']))
        mail.send(msg)
        app.logger.warning("THE EMAIL IS SENT")



######################################################### Utility Functions ############################################

def dict_diff(first, second):
    """ Return a dict of keys that differ with another config object.  If a value is
        not found in one fo the configs, it will be represented by KEYNOTFOUND.
        @param first:   Fist dictionary to diff.
        @param second:  Second dicationary to diff.
        @return diff:   Dict of Key => (first.val, second.val)
    """
    diff = {}
    email_diff = {}
    # Check all keys in first dict
    for key in first.keys():
        if (not second.has_key(key)):
            app.logger.error("Error for key: "+key)
            diff[key] = (first[key], KEYNOTFOUND)
        elif (first[key] != second[key]):
            diff[key] =  second[key]
            email_diff[key] =  (first[key],second[key])
    # Check all keys in second dict to find missing
    for key in second.keys():
        if (not first.has_key(key)):
            app.logger.error("Error for key: "+key)
            diff[key] = (KEYNOTFOUND, second[key])
    return (diff,email_diff)

def get_cidr_data(name):
    """ Return data from the CIDR properties.
        @param name:   Component Name.
        @return val:   Values of the data centers in CIDR properties.
    """
    global base_url
    s = requests.Session()
    s.auth = eg_auth_obj
    full_url = urljoin(base_url, '/config-gtm/v1/domains/cidns.cc.akadns.net/properties/coupons.'+name+'.cidr')
    result = s.get(full_url)
    data = result.json()
    s.close()
    val=""
    lv_count=0
    sc_count=0
    for x in data["trafficTargets"]:
    	if ".geo.cidns.cc.akadns.net" in x["handoutCName"]:
    		val = "Both-cidr"
    		break
        elif ".ca1.coupons.com" in x["handoutCName"]:
        	sc_count=sc_count+1
        elif ".nv1.coupons.com" in x["handoutCName"]:
        	lv_count=lv_count+1
    if sc_count==4:
        	val = "SC5-cidr"
    elif lv_count==4:
        	 val = "LV1-cidr"
    return val

def extract_hname(data,c_name):
    rdata={}
    handout_names=[]
    for x in data['trafficTargets']:
        data = re.search(clippy_azure_regex[c_name], x['handoutCName']).group(1)
        handout_names.append(data)
    rdata.update({c_name:handout_names})
    return rdata

def get_geo_data(name):
   global viewonlycomps
   viewonlycomps.append(name)
   return "Both-geo"

def get_azuregeo_data(name):
   global viewonlyazurecomps
   viewonlyazurecomps.append(name)
   return "Both-geo"

def get_json_data(comp,x):
    """ Return data from the Akamai portal "Control.akamai.com.
        @param comp: Component Name.
        @param x: zone.
    """
    global base_url,comp_dict,riq_dict
    zone=x
    riq_dict[zone]={}
    azure_dict[zone]={}
    data = {}
    s = requests.Session()
    s.auth = eg_auth_obj
    full_url = urljoin(base_url, '/config-dns/v1/zones/'+ zone)
    result = s.get(full_url)
    data = result.json()
    s.close()
    if zone in zones:
          for i, old_cname in enumerate(data['zone']['cname']):
             if data['zone']['cname'][i]['name'] in comp:
                  if 'cidr.cidns.cc.akadns.net.' in  data['zone']['cname'][i]['target']:                     
                          comp_dict[zone][data['zone']['cname'][i]['name'].encode('ascii','ignore')]=get_cidr_data(data['zone']['cname'][i]['name'])                    
                  elif 'geo.cidns.cc.akadns.net.' in  data['zone']['cname'][i]['target']:
                         comp_dict[zone][data['zone']['cname'][i]['name'].encode('ascii','ignore')]=get_geo_data(data['zone']['cname'][i]['name'])
                  elif 'ca1.' in data['zone']['cname'][i]['target']:
                           comp_dict[zone][data['zone']['cname'][i]['name'].encode('ascii','ignore')]="SC5-fast"
                  elif 'nv1.' in data['zone']['cname'][i]['target']:
                           comp_dict[zone][data['zone']['cname'][i]['name'].encode('ascii','ignore')]="LV1-fast"
    elif zone in azure_zones:
            for i, old_cname in enumerate(data['zone']['cname']):
                 if data['zone']['cname'][i]['name'] in comp:
                      if 'cidr.cidns.cc.akadns.net.' in  data['zone']['cname'][i]['target']:                     
                          azure_dict[zone][data['zone']['cname'][i]['name'].encode('ascii','ignore')]=get_azure_data(data['zone']['cname'][i]['name'])                    
                      elif 'geo.cidns.cc.akadns.net.' in  data['zone']['cname'][i]['target']:
                         azure_dict[zone][data['zone']['cname'][i]['name'].encode('ascii','ignore')]=get_azuregeo_data(data['zone']['cname'][i]['name'])
                      elif 'east.' in data['zone']['cname'][i]['target']:
                           azure_dict[zone][data['zone']['cname'][i]['name'].encode('ascii','ignore')]="east-fast"
                      elif 'west.' in data['zone']['cname'][i]['target']:
                           azure_dict[zone][data['zone']['cname'][i]['name'].encode('ascii','ignore')]="west-fast"
    elif zone in riq_zones:
            for i, old_cname in enumerate(data['zone']['cname']):
                 if data['zone']['cname'][i]['name'] in comp:
                      riq_dict[zone][data['zone']['cname'][i]['name'].encode('ascii','ignore')]=data['zone']['cname'][i]['target']
    app.logger.critical("comp:{0} azure_comp:{4} zone:{1} populated_dict(riq_dict):{2} populated_dict(azure_dict):{3}".format(comp,azure_comp,zone,riq_dict[zone],azure_dict[zone]))

##getting and making call for azure endpoints##
def get_azure_loop_data(names):
    global base_url, comp_dict, riq_dict
    zone = x
    riq_dict[zone] = {}
    azure_dict[zone] = {}
    data = {}
    retured_data=OrderedDict() 
    s = requests.Session()
    s.auth = eg_auth_obj
    full_url = urljoin(base_url, '/config-dns/v1/zones/' + zone)
    for url in clippy_azure_url.keys():
        full_url = base_url+'/config-gtm/v1/domains/cidns.cc.akadns.net/properties/'+clippy_azure_url[url]
        result = s.get(full_url)
        if result.status_code==200:
            data = result.json()
            retured_data.update(extract_hname(data,url))
	# after each respone extracting and getting the handout name
    s.close()
    return  retured_data

def post_data_fast(fast_list,chg_comp_dict,zone,comments,email_diff):
   """ Post data to Fast DNS in Akamai portal .
        @param : Self explainatory.
   """
   app.logger.critical("inside fast: Zone:{0} Fast_list:{1} Changes:{2}".format(zone,fast_list,chg_comp_dict))
   headers = {'Content-Type': 'application/json'}
   s = requests.Session()
   s.auth = eg_auth_obj
   full_url = urljoin(base_url, '/config-dns/v1/zones/'+zone)
   result = s.get(full_url)
   data = result.json()
   app.logger.critical("This is the data received from akamai %s",json.dumps(data,sort_keys=True, indent=4))
   data['zone']['instance'] = unicode("%s: %s" % (session['username'], comments))
   data["zone"]["soa"]["serial"]=data["zone"]["soa"]["serial"]+1
   if zone=="couponnet.co.uk":
       for i, old_cname in enumerate(data['zone']['cname']):
          if data['zone']['cname'][i]["name"] in fast_list:
             if chg_comp_dict[data['zone']['cname'][i]["name"]].split("-")[0]=="Both":
                  flash("For couponnet.co.uk traffic cannot be distributed in both data centres. Contact Admin", "warning")
                  app.logger.warning("Coupons:For couponnet.co.uk traffic cannot be distributed in both data centres")
                  return "fail"
             elif chg_comp_dict[data['zone']['cname'][i]["name"]].split("-")[0]=="SC5":
                  data["zone"]["cname"][i]["target"]= "fd-ca1.couponnet.co.uk."
             elif chg_comp_dict[data['zone']['cname'][i]["name"]].split("-")[0]=="LV1":
                  data["zone"]["cname"][i]["target"]= "fd-nv1.couponnet.co.uk."
             else:
                   flash("nothing matched", "danger")
                   app.logger.error("Coupons:For couponnet.co.uk nothing matched in fast list")
                   return "fail"
   elif zone=="retaileriq.com":
       for i, old_cname in enumerate(data['zone']['cname']):
          if data['zone']['cname'][i]["name"] in fast_list:
             if chg_comp_dict[data['zone']['cname'][i]["name"]].split("-")[0]=="Both":
                  flash("For retaileriq.com traffic cannot be distributed in both data centres. Contact Admin", "warning")
                  app.logger.warning("Coupons:For retaileriq.com traffic cannot be distributed in both data centres")
                  return "fail"
             elif chg_comp_dict[data['zone']['cname'][i]["name"]].split("-")[0]=="SC5":
                  data["zone"]["cname"][i]["target"]= "ca1.rd.retaileriq.com."
             elif chg_comp_dict[data['zone']['cname'][i]["name"]].split("-")[0]=="LV1":
                  data["zone"]["cname"][i]["target"]= "nv1.rd.retaileriq.com."
             else:
                   flash("nothing matched", "danger")
                   app.logger.error("Coupons:For retaileriq.com nothing matched in fast list")
                   return "fail"   
   elif zone=="coupons.com":
     for i, old_cname in enumerate(data['zone']['cname']):
        if data['zone']['cname'][i]["name"] in fast_list:
             if chg_comp_dict[data['zone']['cname'][i]["name"]].split("-")[0]=="Both":
                  data["zone"]["cname"][i]["target"]="coupons."+data['zone']['cname'][i]["name"]+".cidr.cidns.cc.akadns.net."
             elif chg_comp_dict[data['zone']['cname'][i]["name"]].split("-")[0]=="SC5":
                  data["zone"]["cname"][i]["target"]= data['zone']['cname'][i]["name"]+".ca1."+zone+"."
             elif chg_comp_dict[data['zone']['cname'][i]["name"]].split("-")[0]=="LV1":
                  data["zone"]["cname"][i]["target"]= data['zone']['cname'][i]["name"]+".nv1."+zone+"."
             elif chg_comp_dict[data['zone']['cname'][i]["name"]].split("-")[0]=="east":
                  data["zone"]["cname"][i]["target"]= data['zone']['cname'][i]["name"]+".east."+zone+"."
             elif chg_comp_dict[data['zone']['cname'][i]["name"]].split("-")[0]=="west":
                  data["zone"]["cname"][i]["target"]= data['zone']['cname'][i]["name"]+".west."+zone+"."
             else:
                   flash("nothing matched", "danger")
                   app.logger.error("Coupons:For coupons.com nothing matched in fast list")
                   return "fail"
   elif zone in riq_zones:
     for i, old_cname in enumerate(data['zone']['cname']):
        if data['zone']['cname'][i]["name"] in chg_comp_dict.keys():
             data["zone"]["cname"][i]["target"]= chg_comp_dict[data['zone']['cname'][i]["name"]]
   app.logger.warning(" This is the data Clippy is trying to post to Fast DNS:\n %s ",json.dumps(data,sort_keys=True, indent=4))
   print(">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>",full_url, headers, data)
   resp = s.post(full_url, headers=headers, data=json.dumps(data))
   if resp.status_code >= 300:
        flash("Unable to submit changes: %s" % resp.text, "danger")
        app.logger.error("In Fast DNA unable to submit changes: %s" % resp.text)
        return "fail"
   else:
        flash("The Cname change is successfully in Fast DNS", "success")
        app.logger.warning("The Cname change is successfully in Fast DNS")
        #sendemail(email_diff,zone,comments)
        return "pass"
   s.close()

def post_data_cidr(cidr_comp,dc,zone,comments):
   """ Post data to Cidr Property in Akamai portal .
        @param : Self explainatory.
   """
   headers = {'Content-Type': 'application/json'}
   s = requests.Session()
   s.auth = eg_auth_obj
   comments = str(session['username'])+': '+comments
   full_url = urljoin(base_url, '/config-gtm/v1/domains/cidns.cc.akadns.net/properties/coupons.'+cidr_comp+'.cidr?domainModificationComments='+comments)
   result = s.get(full_url)
   data = result.json()
   if "links" in data: del data["links"]
   for i in range(4):
       if data["trafficTargets"][i]["datacenterId"]==5400:
           if dc=="Both":
               data["trafficTargets"][i]["handoutCName"]="coupons."+cidr_comp+".geo.cidns.cc.akadns.net"
           elif dc=="SC5":
           	   data["trafficTargets"][i]["handoutCName"]=cidr_comp+".ca1.coupons.com"
           elif dc=="LV1":
           	   data["trafficTargets"][i]["handoutCName"]=cidr_comp+".nv1.coupons.com"
       elif data["trafficTargets"][i]["datacenterId"]==3131:
           if dc=="Both" or dc=="LV1":
               data["trafficTargets"][i]["handoutCName"]=cidr_comp+".nv1.coupons.com"
           elif dc=="SC5":
           	   data["trafficTargets"][i]["handoutCName"]=cidr_comp+".ca1.coupons.com"
       elif data["trafficTargets"][i]["datacenterId"]==3132 or data["trafficTargets"][i]["datacenterId"]==3133:
           if dc=="Both" or dc=="SC5":
               data["trafficTargets"][i]["handoutCName"]=cidr_comp+".ca1.coupons.com"
           elif dc=="LV1":
           	   data["trafficTargets"][i]["handoutCName"]=cidr_comp+".nv1.coupons.com"
       else:
           flash("nothing matched in DC ID", "danger")
           app.logger.error("Coupons:For coupons.com nothing matched for %s",cidr_comp)
           return "fail"
   app.logger.warning("Coupons:%s This is the data Clippy is trying to post to Cidr Properties for component:%s ,datacenter: %s,zone:%s",json.dumps(data), cidr_comp, dc, zone)
   resp = s.put(full_url, headers=headers, data=json.dumps(data))
   if resp.status_code >= 300:
        message="For "+cidr_comp+" Unable to submit changes: %s" % resp.text
        flash(message, "danger")
        app.logger.error(message)
        return "fail"
   else:
        return "pass"
   s.close()

def post_data(sc5_list,lv1_list,comments,zone):
   """ Post data to the Akamai portal "Control.akamai.com.
        @param : Self explainatory.
   """
   global base_url,zones,comps,comp_dict
   fast_case="pass"
   fast_list=[]
   cidr_list=[]
   first_indx= zones.index(zone)
   chg_comp_dict={}
   if not comp_dict[zone]:
   	   get_json_data(comps[zones.index(zone)],zone)
   for x in comps[first_indx]:
       if x in sc5_list and x in lv1_list:
           chg_comp_dict[x]="Both-"+comp_dict[zone][x].split('-')[1]
       elif x in sc5_list:
           chg_comp_dict[x]="SC5-"+comp_dict[zone][x].split('-')[1]
       elif x in lv1_list:
            chg_comp_dict[x]="LV1-"+comp_dict[zone][x].split('-')[1]
       else:
       	  flash("Both the check-boxes for : %s cannot be blank.\nPlease select one" % x, "danger")
          app.logger.error("Both the check-boxes for : %s cannot be blank.\nPlease select one" % x)
       	  return redirect("/zone/"+zone)

   comp_delta,email_diff = dict_diff(comp_dict[zone], chg_comp_dict)
   app.logger.warning("Coupons:Zone:%s Before:%s After:%s Change:%s",zone,comp_dict[zone],chg_comp_dict,comp_delta)
   if not comp_delta:
       flash("No change is done.Nothing to submit", "danger")
       app.logger.error("No change is done.Nothing to submit")
       return redirect("/zone/"+zone)
   else:
       for key,val in comp_delta.items():
   	        if val.split('-')[1]=="fast":
   	    	    fast_list.append(key)
   	    	elif val.split('-')[1]=="cidr":
   	    	    cidr_list.append(post_data_cidr(key,val.split('-')[0],zone,comments))
       if fast_list:
             fast_case=post_data_fast(fast_list,chg_comp_dict,zone,comments,email_diff)
       if cidr_list:
         if not "fail" in cidr_list :
       	     flash("The Cname change is successfully in Cidr Properties", "success")
             app.logger.warning("Coupons:The Cname change is successfully in Cidr Properties ")
             if fast_case=="pass":
                 sendemail(email_diff,zone,comments)
       elif fast_case=="pass":
                 sendemail(email_diff,zone,comments)
       else:
            flash("The Change was not submitted properly.\n1.Please check log and Akamai Portal.\n2.Please refresh the page.", "danger")
            app.logger.error("Coupons:The Change was not submitted properly.Please debug appropriately.")
   return redirect("/zone/"+zone)


######################################################### Common Functions ############################################

renew_zones=['new_azure_renew.com']

@app.route("/")
def index():
    return render_template('index.html')

@app.route('/dc',methods = ['POST', 'GET'])
def dc():
   if request.method == 'POST':
       zone=request.form['zon']
   if zone in zones:       
       return redirect("/zone/"+zone)
   elif zone in riq_zones:
       return redirect("/riq_zone/"+zone)
   elif zone in azure_zones:
       return redirect("/azure_zone/"+zone)
   elif zone in gcp_zones:
       return redirect("/gcp_zone/")
   elif zone in renew_zones:
       return redirect("/new_azure_zone/new_azure_renew.com")


######################################################### Coupons code Functions ############################################

@app.route('/zone/<string:zone>')
def home(zone):
    global comps,comp_dict,viewonlycomps
    get_json_data(comps[zones.index(zone)],zone)
    app.logger.critical("[Coupons:"+zone+":Availabe Components]%s"%comp_dict)
    comp=comps[zones.index(zone)]
    return render_template('home.html',zones=zones,comp=comp,dicto=comp_dict[zone],zon=zone,viewonlycomps=viewonlycomps)


@app.route('/submit/<string:zone>',methods = ['POST', 'GET'])
def submit(zone):
   global comp_dict,viewonlycomps
   if request.method == 'POST':
       sc5_list=request.form.getlist('SC5')
       lv1_list=request.form.getlist('LV1')
       slack1=request.form.getlist('slack')
       print (slack1)
       for x in viewonlycomps:
         if x in comps[zones.index(zone)]:
             if "Both" in comp_dict[zone][x]:
                sc5_list.append(x)
                lv1_list.append(x)
             elif "SC5" in comp_dict[zone][x]:
                 sc5_list.append(x)
             elif "LV1" in comp_dict[zone][x]:
                 lv1_list.append(x)
       comments=request.form.get('comments')
      # print(request.form.getlist('slack'),">>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>")
       if comments:
           if session.get('logged_in'):
               post_data(sc5_list,lv1_list,comments,zone)
           else:
                 return '''<html>Please login to proceed.</html>'''
       else:
               flash("Please write a comment describing the change.","warning")
   return redirect("/zone/"+zone)

######################################GCP Codes#####################################################################

@app.route('/gcp_zone/gcp.com',methods=['GET','POST'])
def gcp():
    #zone='gcp.com'
    global gcp_comps,gcp_dict,maps_dict,g_list
    if request.method == 'GET':
        gval = list(gcp_comps.values())
        #print ("this issssssssssssssssssss testttttttttttttttttttttttttttttttttttt", tst)
        gcp_data = get_gcp_data(gval)
        gcp_data = render_template('GCP.html',maps_dict = maps_dict,gcp_comps=gcp_comps,g_list=g_list)#,g_list=g_list)#,gcp_comp=data,zon=zone,zones=zones,viewonlygcpcomps=viewonlygcpcomps)

    return gcp_data

def get_gcp_data(gval):
    global base_url,gcp_comps, gcp_dict, maps_dict,g_list
    gdata = []
    g_list=[]
    for url in gval:
        headers = {'Content-Type': 'application/json'}
        s = requests.Session()
        s.auth = eg_auth_obj
        full_url = base_url + '/config-dns/v2/zones/receiptiq.com/names/' + url + '/types/A'
        # print(full_url)
        result = s.get(full_url, headers=headers)
        if result.status_code == 200:
            gcp_data = result.json()
            current_state = gcp_data['rdata'][0]
            current_name = gcp_data['name']
            for k, v in maps_dict.items():
                if current_state in maps_dict.values() and current_state == v:
                   gdata = k
                   g_list.append(gdata)
#                   print("gdata>>>>>>>>>>>>>>>>", k)
                    #data = current_state
                    #print("current stateeeee", i)
                    #print ("thiss issssssssssssssssssss cureeeeeeeeeeeeee", maps_dict.keys())

    return gdata

@app.route('/gcp_zone_post/gcp.com',methods=['POST'])
def gcp_post():
    global base_url,gcp_comps, gcp_dict, maps_dict,g_list
    if request.method == 'POST':
        comments = request.form['comments']
        changes=[]
        for comps in clippy_azure_url.keys():
            result = get_and_prepare(comps,comments,request.form.getlist(comps))
            if result:
                changes.append(result[0])
        if not changes:
            flash("No change is done.Nothing to submit", "danger")
        else:
            flash("change is done in "+str(changes)+"", "success")
    return redirect("/gcp_zone/gcp.com")

#########################################################Renew new codes################################################
azurenew_comps = {'codes-east': "origin-codes-east.coupons.com", 'codes-west': "origin-codes-west.coupons.com",
                  'codesapiweb_E': "origin-codesapiweb-east.coupons.com",
                  'codesapiweb-W': "origin-codesapiweb-west.coupons.com"}
azurenew_maps_dict = dict(FE="9e64b0e9-4553-41ca-ada4-4e064be73885.cloudapp.net.",
                          FW="ea5d7601-6ca4-4b09-b72c-68f651a0b8d3.cloudapp.net.",
                          BE="appgatewayapi.eastus.cloudapp.azure.com.",
                          BW="appgatewayapi.westus.cloudapp.azure.com.")
newazureval = azurenew_comps
azure_list = []
post_data = {}
payload_data=[]


@app.route('/new_azure_zone/new_azure_renew.com', methods=['GET'])
def new_azure():
    # zone='gcp.com'
    global azurenew_comps, azurenew_maps_dict, azure_data
    azure_list = []
    if request.method == 'GET':
        newazureval = azurenew_comps
        azure_list = get_newazure_data(newazureval)
        print(azure_list, "azure_listview")
        # print(gcp_comps,"gcp_compsgcp_compsgcp_comps")
        azure_data = render_template('new_azure.html', azurenew_maps_dict=azurenew_maps_dict,
                                     azurenew_comps=azurenew_comps,
                                     azure_list=azure_list,zon='new_azure_renew.com')  # ,gcp_comp=data,zon=zone,zones=zones,viewonlygcpcomps=viewonlygcpcomps)
    return azure_data


def get_newazure_data(newazureval):
    global base_url, gcp_comps, gcp_dict, maps_dict, gcp_data
    # gdata = []
    azure_list = []
    for key, url in newazureval.items():
        headers = {'Content-Type': 'application/json'}
        s = requests.Session()
        s.auth = eg_auth_obj
        full_url = base_url + '/config-dns/v2/zones/coupons.com/names/' + url + '/types/CNAME'
        # print(full_url)
        result = s.get(full_url, headers=headers)
        if result.status_code == 200:
            newazure_data = result.json()
            # print(newazure_data)
            current_state = newazure_data['rdata'][0]
            current_name = newazure_data['name']
            for k, v in azurenew_maps_dict.items():
                if current_state in azurenew_maps_dict.values() and current_state == v:
                    azure_list.append({key: k})
    print(azure_list)
    return azure_list




@app.route('/new_azure_zone/new_azure_renew.com', methods=['POST'])
def renew_post():
    global azurenew_comps, azurenew_maps_dict, azure_data
    if request.method == 'POST':
        comments = request.form['comments']
        renewpostdata={}
        renewpostdata['codes-east'] = request.form['codes-east']
        renewpostdata['codes-west'] = request.form['codes-west']
        renewpostdata['codesapiweb_E'] = request.form['codesapiweb_E']
        renewpostdata['codesapiweb_W'] = request.form['codesapiweb-W']
        print(renewpostdata)
        if comments:
            if session.get('logged_in'):
                renew_prepare_post(renewpostdata, comments)
            else:
                return '''<html>Please login to proceed.</html>'''
        else:
            flash("Please write a comment describing the change.", "warning")
    return redirect("/new_azure_zone/new_azure_renew.com")
    #renew_prepare_post(renewpostdata)

def renew_prepare_post(renewpostdata, comments):
    changes_detected=[]
    if comments:
        for key, url in newazureval.items():
            headers = {'Content-Type': 'application/json'}
            s = requests.Session()
            s.auth = eg_auth_obj
            full_url = base_url + '/config-dns/v2/zones/coupons.com/names/' + url + '/types/CNAME'
            # print(full_url)
            result = s.get(full_url, headers=headers)
            if result.status_code == 200:
                payload_data.append(result.json())
                #print(payload_data,"???????????????????????????")
        for k, v in renewpostdata.items():
            site_data = azurenew_maps_dict.get(v)
            region_data = azurenew_comps.get(k)
            changes_detected.append(v)
            # print(region_data , ':', site_data)
            post_data[region_data] = site_data
        #print('POST DATA', post_data)
        #print('payload_data', payload_data)
        for R, S in post_data.items():
            for x in range(len(payload_data)):
                if R in payload_data[x]['name']:
                    payload_data[x]['rdata'] = [S]
                   # print('This is  >>>>>>Akamai', payload_data)
                    renew_post_process(payload_data, comments, changes_detected)
    return changes_detected

def renew_post_process(payload_data, comments, renew_changes_detected):
    if comments:
        for key, url in newazureval.items():
            headers = {'Content-Type': 'application/json'}
            s = requests.Session()
            s.auth = eg_auth_obj
            full_url = base_url + '/config-dns/v2/zones/coupons.com/names/' + url + '/types/CNAME'+'?domainModificationComments='+comments+''
            print(full_url)
            for x in range(len(payload_data)):
                if url == payload_data[x]['name']:
                    data = json.dumps(payload_data[x])
                    print(data)
                    result = s.put(full_url, headers=headers, data=json.dumps(data))
                    if result.status_code == 200 or result.status_code < 210:
                        data = result.json()
                        flash("change is done in " + str(renew_changes_detected) + "", "success")
                        result = True
                    else:
                        result = False
    return result

#########################################################Azure code functions############################################


@app.route('/azure_zone/<string:zone>',methods=['GET','POST'])
def azure(zone):
    global azure_comps,azure_dict,viewonlyazurecomps
    if request.method == 'GET':
        data = get_azure_loop_data(azure_comps[zones.index(zone)])
	data = render_template('Azure.html',azure_comp=data,zon=zone,zones=zones,viewonlycomps=viewonlycomps)
    return data

def compare_dict(comps,formdata,handout):
    formdata = formdata
    handout_names = [re.search(clippy_azure_regex[comps], x['handoutCName']).group(1) for x in handout]
    comp_val=False
    new_val=[]
    if len(formdata) ==len(handout_names):
        if sorted(formdata) ==sorted(handout_names):
            comp_val = True
        else:
            comp_val=False
    else:
        for fm in sorted(formdata):
            for  hm in sorted(handout_names):
                if fm==hm:
                    comp_val = True
                else:
                    comp_val = False
                    break
    return comp_val

def get_and_prepare(comps,comments,formdata):
    if comments:
        changes_detected=[]
        headers = {'Content-Type': 'application/json'}
        s = requests.Session()
        s.auth = eg_auth_obj
        full_url = base_url + '/config-gtm/v1/domains/cidns.cc.akadns.net/properties/'+clippy_azure_url.get(comps)+'?domainModificationComments='+comments+''
        result = s.get(full_url, headers=headers)
        if result.status_code == 200 and result.status_code <= 210 :
            data =result.json()
            list_handout =data['trafficTargets']
            if not compare_dict(comps,formdata,list_handout):
                changes_detected.append(comps)
                payload = prepare_data(comps,formdata,data)
                post_data_url(full_url,payload)
    return changes_detected

def prepare_data(comps,formdata,data):
    print(formdata)
    if comps=='Clippytest':
        if len(formdata)==1:
           data['trafficTargets'][0]['handoutCName']='clippytest.'+formdata[0]+'.coupons.com'
           data['trafficTargets'][1]['handoutCName']='clippytest.'+formdata[0]+'.coupons.com'
        else:
            data['trafficTargets'][0]['handoutCName'] = 'clippytest.' + formdata[0] + '.coupons.com'
            data['trafficTargets'][1]['handoutCName']='clippytest.'+formdata[1]+'.coupons.com'
    if comps=='CMS-FE':
	if len(formdata)==1:
	   data['trafficTargets'][0]['handoutCName']='origin-cms-'+formdata[0]+'.coupons.com'
           data['trafficTargets'][1]['handoutCName']='origin-cms-'+formdata[0]+'.coupons.com'
    	else:
           data['trafficTargets'][0]['handoutCName'] = 'origin-cms-' + formdata[0]+'.coupons.com'
           data['trafficTargets'][1]['handoutCName']='origin-cms-'+formdata[1]+'.coupons.com'
    if comps=='CMS-BE':
	if len(formdata)==1:
	   data['trafficTargets'][0]['handoutCName']='origin-codesapi-'+formdata[0]+'.coupons.com'
           data['trafficTargets'][1]['handoutCName']='origin-codesapi-'+formdata[0]+'.coupons.com'
        else:
           data['trafficTargets'][0]['handoutCName'] = 'origin-codesapi-' + formdata[0] + '.coupons.com'
           data['trafficTargets'][1]['handoutCName']='origin-codesapi-'+formdata[1]+'.coupons.com'
    if comps=='renew-FE':
	if len(formdata)==1:
	   data['trafficTargets'][0]['handoutCName']='origin-codes-'+formdata[0]+'.coupons.com'
           data['trafficTargets'][1]['handoutCName']='origin-codes-'+formdata[0]+'.coupons.com'
	   data['trafficTargets'][2]['handoutCName']='origin-codes-'+formdata[0]+'.coupons.com'
        else:
           data['trafficTargets'][0]['handoutCName'] = 'origin-codes-' + formdata[0] + '.coupons.com'
           data['trafficTargets'][1]['handoutCName']='origin-codes-'+formdata[1]+'.coupons.com'
	   data['trafficTargets'][2]['handoutCName']='origin-codes-'+formdata[0]+'.coupons.com'
    if comps=='renew-BE':
	if len(formdata)==1:
	   data['trafficTargets'][0]['handoutCName']='origin-codesapiweb-'+formdata[0]+'.coupons.com'
           data['trafficTargets'][1]['handoutCName']='origin-codesapiweb-'+formdata[0]+'.coupons.com'
	   data['trafficTargets'][2]['handoutCName']='origin-codesapiweb-'+formdata[0]+'.coupons.com'
        else:
           data['trafficTargets'][0]['handoutCName'] = 'origin-codesapiweb-' + formdata[0] + '.coupons.com'
           data['trafficTargets'][1]['handoutCName']='origin-codesapiweb-'+formdata[1]+'.coupons.com'
	   data['trafficTargets'][2]['handoutCName']='origin-codesapiweb-'+formdata[0]+'.coupons.com'
    if comps=='CodesPlugin-FE':
	if len(formdata)==1:
	   data['trafficTargets'][0]['handoutCName']='codesplugin-'+formdata[0]+'.coupons.com'
           data['trafficTargets'][1]['handoutCName']='codesplugin-'+formdata[0]+'.coupons.com'
	   data['trafficTargets'][2]['handoutCName']='codesplugin-'+formdata[0]+'.coupons.com'
        else:
           data['trafficTargets'][0]['handoutCName'] = 'codesplugin-' + formdata[0] + '.coupons.com'
           data['trafficTargets'][1]['handoutCName']='codesplugin-'+formdata[1]+'.coupons.com'
	   data['trafficTargets'][2]['handoutCName']='codesplugin-'+formdata[0]+'.coupons.com'
    if comps=='CodesPlugin-BE':
	if len(formdata)==1:
	   data['trafficTargets'][0]['handoutCName']='codespluginweb-'+formdata[0]+'.coupons.com'
           data['trafficTargets'][1]['handoutCName']='codespluginweb-'+formdata[0]+'.coupons.com'
	   data['trafficTargets'][2]['handoutCName']='codespluginweb-'+formdata[0]+'.coupons.com'
        else:
           data['trafficTargets'][0]['handoutCName'] = 'codespluginweb-' + formdata[0] + '.coupons.com'
           data['trafficTargets'][1]['handoutCName']='codespluginweb-'+formdata[1]+'.coupons.com'
           data['trafficTargets'][2]['handoutCName']='codespluginweb-'+formdata[0]+'.coupons.com'
    #print(json.dumps(data, indent=4, sort_keys=True))
    return data

def post_data_url(url,data):
    result=""
    headers = {'Content-Type': 'application/json'}
    s = requests.Session()
    s.auth = eg_auth_obj
    full_url = url
    result = s.put(full_url, headers=headers, data=json.dumps(data))
    if result.status_code == 200 or result.status_code < 210:
        data = result.json()
        print("sucess")
        result=True
    else:
        result=False
    return result

@app.route('/azure_zone_post/<string:zone>',methods=['POST'])
def azure_post(zone):
    global azure_comps,azure_dict,viewonlyazurecomps
    if request.method == 'POST':
        comments = request.form['comments']
        changes=[]
        for comps in clippy_azure_url.keys():
            result = get_and_prepare(comps,comments,request.form.getlist(comps))
            if result:
                changes.append(result[0])
        if not changes:
            flash("No change is done.Nothing to submit", "danger")
        else:
            flash("change is done in "+str(changes)+"", "success")
    return redirect("/azure_zone/"+zone)

@app.route('/azure_submit/<string:zone>',methods = ['POST'])
def azure_submit(zone):
   global azure_dict,viewonlyazurecomps
   if request.method == 'POST':
       east_list=request.form.getlist('east')
       west_list=request.form.getlist('west')
       for x in viewonlyazurecomps:
         if x in azure_comps[zones.index(zone)]:
             if "Both" in azure_dict[zone][x]:
                east_list.append(x)
                west_list.append(x)
             elif "east" in azure_dict[zone][x]:
                 east_list.append(x)
             elif "west" in azure_dict[zone][x]:
                 west_list.append(x)
       comments=request.form.get('comments')
       if comments:
           if session.get('logged_in'):
               post_data(east_list,west_list,comments,zone)
           else:
                 return '''<html>Please login to proceed.</html>'''
       else:
               flash("Please write a comment describing the change.","warning")
   return redirect("/azure_zone/"+zone)


######################################################### RIQ code Functions ############################################


@app.route('/riq_zone/<string:zone>')
def riq_home(zone):
    global riq_dict,patner_list,riq_all_comp,riq_zones,pattern_uxm,pattern_glsb
    riq_comp=riq_all_comp[riq_zones.index(zone)]
    app.logger.critical("[RIQ:"+zone+":Availabe Components]%s"%riq_comp)
    patner=patner_list[riq_zones.index(zone)]
    get_json_data(riq_comp,zone)
    return render_template('riq_home.html',riq_dict=riq_dict,zones=riq_zones,patner_list=collections.OrderedDict(sorted(patner.items())),zon=zone,re=re,pattern_uxm=pattern_uxm,pattern_glsb=pattern_glsb)


@app.route('/riq_submit/<string:zone>',methods = ['POST', 'GET'])
def riq_submit(zone):
   global riq_dict,patner_list,riq_all_comp,riq_zones
   riq_post_dict={}
   riq_comp=riq_all_comp[riq_zones.index(zone)]

   if request.method == 'POST':
       for keys in riq_comp:
            riq_api_keys=re.match(r'([a-z0-9A-Z-]*[\.-])(apir|apis)',keys)
            value=request.form.get(keys)     
            if value=='-1' or value=='-2' :
                  app.logger.critical("Please delete "+keys+" as it doesn't have a valid entry in Akamai Fast DNS")
            elif riq_api_keys:
                  matches=re.match(pattern_glsb,riq_dict[zone][keys])
                  if not value:
                       if riq_api_keys.group(2)=='apis':
                           value=request.form.get(riq_api_keys.group(1)+'apir')
                       elif riq_api_keys.group(2)=='apir':
                          value=request.form.get(riq_api_keys.group(1)+'apis')
                  if matches:
                      riq_post_dict[keys]=matches.group(1)+value+matches.group(3)+matches.group(4)
                  else:
                      app.logger.critical("Couldn't match for %s"%riq_dict[zone][keys])
            else:
                  if zone == 'receiptiq.com':
                          if value == '00':
                              riq_post_dict[keys]='ca2.uxm.receiptiq.com.'
                          elif value == '100':
                              riq_post_dict[keys]='va2.uxm.receiptiq.com.'
                  elif zone == 'pdn.retaileriq.com':
                          if value == '00':
                              riq_post_dict[keys]='pn1-uxm.pdn.coupons.com.'
                          elif value == '100':
                              riq_post_dict[keys]='pn2-uxm.pdn.coupons.com.'
                              
       app.logger.critical("Comparing:\n{0}\nAND\n{1}".format(riq_dict[zone], riq_post_dict))
       riq_comp_delta,riq_email_diff = dict_diff(riq_dict[zone], riq_post_dict)
       app.logger.critical("[RIQ:"+zone+":Entire data submitted:]%s"%riq_post_dict)
       app.logger.critical("[RIQ:"+zone+":Actual Change submitted:]%s"%riq_email_diff)
       comments=request.form.get('comments')
       if not riq_comp_delta:
               flash("No change is done.Nothing to submit", "danger")
               app.logger.error("RIQ:No change is done.Nothing to submit")
       elif not comments:
           flash("Please write a comment describing the change.","warning")
       else:               
           if session.get('logged_in'):               
               outcome=post_data_fast(riq_comp,riq_comp_delta,zone,comments,riq_email_diff)
               if outcome=="pass":
                    sendemail(riq_email_diff,zone,comments)
           else:
                 return '''<html>Please login to proceed.</html>'''
   return redirect("/riq_zone/"+zone)


######################################################### Common Functions ############################################

@app.route("/config/<string:zone>")
def config(zone):
      global riq_zones
      if session.get('logged_in'):
              if zone in zones:       
                  return render_template('config.html',zon=zone,zones=zones,riq_zones=riq_zones)
              elif zone in riq_zones:
                  return render_template('config.html',zon=zone,zones=riq_zones,riq_zones=riq_zones)
	      elif zone in renew_zones:
		  return render_template('config.html',zon='new_azure_renew.com',zones=zones,riq_zones=riq_zones)
      else:
            return '''<html>Please login to proceed.</html>'''   
      
@app.route("/config_add/<string:zone>", methods=['GET', 'POST'])
def config_add(zone):
    global patner_list,riq_all_comp,riq_zones
    riq_comp=riq_all_comp[riq_zones.index(zone)]
    patner=patner_list[riq_zones.index(zone)]
    if request.method == 'POST':
            patnername = request.form['patnername'].capitalize()
            apitype = request.form['apitype']
            riq_cname = request.form['riq_cname']
            retailername = request.form['retailername'].capitalize()
            pvcrt = request.form['pvcrt']
            if riq_cname not in riq_comp:
                riq_api_cname=re.match(r'([a-z0-9A-Z-]*[\.-])(apir|apis)',riq_cname)
                if pvcrt == "yes":
                      retailername=retailername+'|'+pvcrt
                if patnername in patner.keys():
                      if riq_cname in patner[patnername][apitype].keys():
                          patner[patnername][apitype][riq_cname]=retailername
                      else:
                          patner[patnername][apitype].update({riq_cname:retailername})
                          if (riq_api_cname):
                              riq_comp.append(riq_api_cname.group(1)+'apir')
                              riq_comp.append(riq_api_cname.group(1)+'apis')
                          else:
                               riq_comp.append(riq_cname)
                else:
                    patner.update({patnername:{'api':{},'uxm':{}}})
                    patner[patnername][apitype].update({riq_cname:retailername})
                    if (riq_api_cname):
                          print riq_api_cname,"hello"
                          riq_comp.append(riq_api_cname.group(1)+'apir')
                          riq_comp.append(riq_api_cname.group(1)+'apis')
                    else:
                          riq_comp.append(riq_cname)
                app.logger.critical('{0} is added by {1}'.format(riq_cname,session['username']))
                app.logger.critical(json.dumps(patner,sort_keys=True, indent=4))
                app.logger.critical(sorted(riq_comp))
                riq_all_comp[riq_zones.index(zone)]=sorted(riq_comp)
                patner_list[riq_zones.index(zone)]=patner
                with open('/opt/Clippy/riqconfig.py','w') as fh:
                      fh.write('riq_zones='+str(riq_zones)+'\nriq_all_comp='+str(riq_all_comp)+'\npatner_list='+json.dumps(patner_list,sort_keys=True, indent=4))
                      flash("Record added successfully.","success")
                if os.path.exists('/opt/Clippy/riqconfig.pyc'):
                      os.remove("/opt/Clippy/riqconfig.pyc")
            else:
                 flash("Cname %s is already existing in Clippy"%riq_cname,"warning")
    return redirect("/config/"+zone)


@app.route("/config_delete/<string:zone>", methods=['GET', 'POST'])
def config_delete(zone):
    global patner_list,riq_all_comp,riq_zones
    riq_comp=riq_all_comp[riq_zones.index(zone)]
    patner=patner_list[riq_zones.index(zone)]
    if request.method == 'POST':
            patnername = request.form['patnername'].capitalize()
            apitype = request.form['apitype']
            riq_cname = request.form['riq_cname']
            riq_api_cname=re.match(r'([a-z0-9A-Z-]*[\.-])(apir|apis)',riq_cname)
            try:
                    del patner[patnername][apitype][riq_cname]
                    if (riq_api_cname):
                         riq_comp.remove(riq_api_cname.group(1)+'apir')
                         riq_comp.remove(riq_api_cname.group(1)+'apis')
                    else:
                         riq_comp.remove(riq_cname)
                    
                    app.logger.critical('{0} is deleted by {1}'.format(riq_cname,session['username']))
            except:
                  flash("Wrong inputs. Please provide the correct input to delete the records.","danger")
                  return redirect("/config/"+zone)
            app.logger.critical(json.dumps(patner,sort_keys=True, indent=4))
            app.logger.critical(sorted(riq_comp))
            riq_all_comp[riq_zones.index(zone)]=sorted(riq_comp)
            patner_list[riq_zones.index(zone)]=patner
            with open('/opt/Clippy/riqconfig.py','w') as fh:
                  fh.write('riq_zones='+str(riq_zones)+'\nriq_all_comp='+str(riq_all_comp)+'\npatner_list='+json.dumps(patner_list,sort_keys=True, indent=4))
            flash("Record deleted successfully.","success")
            if os.path.exists('/opt/Clippy/riqconfig.pyc'):
                  os.remove("/opt/Clippy/riqconfig.pyc")
    return redirect("/config/"+zone)


@app.route("/login/<string:zone>", methods=['GET', 'POST'])
def login(zone):
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        ld = ldap.initialize(ldap_uri)
        ld.bind_s(ldap_bind_name, ldap_bind_pass)

        flippy_dn = 'CN=RIQTrafficShift,OU=DistributionGroups,OU=Groups,OU=Corporate,DC=corp,DC=coupons,DC=com'
        flippy_result = ld.search_s(flippy_dn, ldap.SCOPE_SUBTREE)
        flippy_members = flippy_result[0][1]['member']

        account_dn = 'CN=Users,DC=corp,DC=coupons,DC=com'
        account_name = 'sAMAccountName=%s' % username
        account_result = ld.search_s(account_dn, ldap.SCOPE_SUBTREE, account_name)
        try:
            account_memberships = account_result[0][1]['memberOf']
        except:
            flash("Invalid Username.", "danger")
            return render_template('login.html',zon=zone)
        is_member = bool(list(set(flippy_members) & set(account_memberships)))

        if not account_result or password == "" or not is_member:
            ld.unbind_s()
            flash("Invalid credentials.", "danger")
            return render_template('login.html',zon=zone)

        user_dn = "CN=%s,CN=Users,DC=corp,DC=coupons,DC=com" % account_result[0][1]['cn'][0]

        try:
            ld.simple_bind_s(user_dn, password)
            session['username'] = username
            flash("Logged in successfully as %s." % username, "success")
            app.logger.critical(session['username']+" has logged in")
            session['logged_in']=True
            if zone in zones:       
                 return redirect("/zone/"+zone)
            elif zone in riq_zones:
                 return redirect("/riq_zone/"+zone)
	    elif zone in azure_zone:
          	 return redirect("/azure_zone/coupons.com")
            elif zone in renew_zones:
                return redirect("/new_azure_zone/new_azure_renew.com")
            
        except ldap.INVALID_CREDENTIALS:
            flash("Invalid credentials.", "danger")
        except:
            flash("Error authenticating.", "danger")
        finally:
            ld.unbind_s()

    return render_template('login.html',zon=zone)


@app.route("/logout/<string:zone>")
def logout(zone):
    flash("%s successfully logout." %session['username'],"success")
    app.logger.critical(session['username']+" has logged out")
    session['logged_in'] = False
    if zone in zones:       
          return redirect("/zone/"+zone)
    elif zone in riq_zones:
          return redirect("/riq_zone/"+zone)
    elif zone in azure_zone:
	  return redirect("/azure_zone/coupons.com")
    elif zone in renew_zones:
        return redirect("/new_azure_zone/new_azure_renew.com")




if __name__=="__main__":
    app.run(threaded=True,host='0.0.0.0',port=4000)
