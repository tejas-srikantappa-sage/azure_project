#data  for clippy
admin_passwd='gsh$Ilm&i'
azure_zones=["Azure.com"]                                                                     #different zones
azure_comps=[
      	["CMS-FE","CMS-BE","renew-FE","renew-BE","CodesPlugin-FE","CodesPlugin-BE"]
        ]                                                                                                                     #components of each zone in order of zone
viewonlyazurecomps=[]                                                                                                              #Components in view only mode
email_to = ["RebuildAlerts@quotient.com","ProductionPlatform@quotient.com","PlatformAlerts@quotient.com"] #to_sent email list
