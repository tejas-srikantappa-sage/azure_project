#data for clippy
zones=["coupons.com","couponnet.co.uk","retaileriq.com"]                                                                     #different zones
comps=[
        ["access","api","cpa","dip","hub","internal","clippytest","testclippy","sftp","sso"],
        ["authorize","bricks","frontdoor","print"],
        ["rd","alb-rd", "bjs-rd", "ge-rd", "dg-rd", "md-rd", "seg-rd", "sfwy-rd", "wag-rd"]
        ]                                                                                                                     #components of each zone in order of zone
viewonlycomps=[]                                                                                                              #Components in view only mode
email_to = ["RebuildAlerts@quotient.com","ProductionPlatform@quotient.com","PlatformAlerts@quotient.com"] #to_sent email list
