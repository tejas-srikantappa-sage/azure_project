riq_zones=['receiptiq.com', 'pdn.retaileriq.com']
riq_all_comp=[[u'abbott.apir', u'abbott.apis', u'alb.apir', u'alb.apis', u'albertsons', u'albertsons.uxm', u'appcard.apir', u'appcard.apis', u'bilo.apir', u'bilo.apis', u'bilo.uxm', u'gfc.apir', u'gfc.apis', u'gfl.apir', u'gfl.apis', u'giantfood', u'giantfoodstores', u'harv.apir', u'harv.apis', u'harv.uxm', u'jewelosco', u'jewelosco.uxm', u'm-alb', u'martinsfoods', u'mrt.apir', u'mrt.apis', u'mrtr.apir', u'mrtr.apis', u'pavilions', u'pavilions.uxm', u'sshp.apir', u'sshp.apis', u'stopandshop', u'test', u'test1.apir', u'test1.apis', u'tgt.apir', u'tgt.apis', u'tomthumb.uxm', u'vst.apir', u'wag-a.apir', u'wag-a.apis', u'wag-b.apir', u'wag-b.apis', u'wag.apir', u'wag.apis', u'winco.apir', u'winco.apis', u'winn.apir', u'winn.apis', u'winn.uxm', u'ytbs.apir', u'ytbs.apis'], [u'bjs', u'test-apir', u'test-apis', u'tgttest-apir', u'tgttest-apis']]
patner_list=[
    {
        "Abbott": {
            "api": {
                "abbott.apir": "Abbott"
            }, 
            "uxm": {}
        }, 
        "Ahold": {
            "api": {
                "gfc.apir": "Giant food carlisle", 
                "gfl.apir": "Giant food landover", 
                "mrt.apir": "Martin's market (m)", 
                "mrtr.apir": "Martin's market (mtrr)", 
                "sshp.apir": "Stop & shop"
            }, 
            "uxm": {
                "giantfood": "Giant food", 
                "giantfoodstores": "Giant food stores", 
                "martinsfoods": "Martin's foods", 
                "stopandshop": "Stop & shop\t"
            }
        }, 
        "Albertson": {
            "api": {
                "alb.apir": "Albertson's"
            }, 
            "uxm": {
                "albertsons": "Albertsons", 
                "albertsons.uxm": "Albertsons uxm", 
                "jewelosco": "Albertson's jewel osco", 
                "jewelosco.uxm": "Albertson's jewel osco", 
                "m-alb": "Albertson's (microsites)", 
                "pavilions": "Pavilions", 
                "pavilions.uxm": "Pavilions uxm", 
                "tomthumb.uxm": "Tomthumb"
            }
        }, 
        "Appcard": {
            "api": {
                "appcard.apir": "Appcard"
            }, 
            "uxm": {}
        }, 
        "Giant food stores": {
            "api": {}, 
            "uxm": {}
        }, 
        "New test": {
            "api": {
                "test1.apir": "New gslb test (example)"
            }, 
            "uxm": {}
        }, 
        "Se grocers": {
            "api": {
                "bilo.apir": "Bilo", 
                "harv.apir": "Harveys", 
                "winn.apir": "Winn-dixie"
            }, 
            "uxm": {
                "bilo.uxm": "Bilo", 
                "harv.uxm": "Harveys", 
                "winn.uxm": "Winn-dixie"
            }
        }, 
        "Target": {
            "api": {
                "tgt.apir": "Target"
            }, 
            "uxm": {}
        }, 
        "Test old": {
            "api": {}, 
            "uxm": {}
        }, 
        "Test uxm": {
            "api": {}, 
            "uxm": {
                "test": "Sample uxm (example)"
            }
        }, 
        "Vestcom": {
            "api": {
                "vst.apir": "Vestcom"
            }, 
            "uxm": {}
        }, 
        "Walgreens": {
            "api": {
                "wag-a.apir": "Walgreens-a", 
                "wag-b.apir": "Walgreens-b", 
                "wag.apir": "Walgreens"
            }, 
            "uxm": {}
        }, 
        "Winco-food": {
            "api": {
                "winco.apir": "Winco-food"
            }, 
            "uxm": {}
        }, 
        "Ytbs": {
            "api": {
                "ytbs.apir": "Ytbs"
            }, 
            "uxm": {}
        }
    }, 
    {
        "Bjs": {
            "api": {}, 
            "uxm": {
                "bjs": "Bjs store"
            }
        }, 
        "Test old-pdn": {
            "api": {
                "test-apir": "Test entry (example)"
            }, 
            "uxm": {}
        }, 
        "Tgt test": {
            "api": {
                "tgttest-apis": "Tgt test"
            }, 
            "uxm": {}
        }
    }
]